angular.module('imdbApp').
component('headerapp', {
    templateUrl: "./header/header.template.html",
    // styleUrls: ['./header/header.css'],
    controller: function headerController() {
        this.myname = "header";
        this.selectedKey = "All";
        this.inputValue;
        this.getselectedvalue = function(e) {
            this.selectedKey = e.target.getAttribute("value");
            this.inputValue = {};
            this.getImdbSearchValue();
        }
        this.getImdbSearchValue = function() {

            this.searchdata = this.inputValue;
        }
    },
    bindings: {
        searchdata: `=`

    }
});